# Deadlog

**Find dead API endpoints before they drain your budget.**

Deadlog is a client-side SaaS developer tool that analyzes API log files to detect unused or "dead" API endpoints that waste cloud infrastructure money.

![Deadlog Screenshot](https://wjfcksy5z5mky.ok.kimi.link)

## Features

- **Log Parsing**: Supports Nginx, AWS CloudWatch, Express, JSON, and CSV formats
- **Endpoint Analysis**: Automatically classifies endpoints as Dead, Low Traffic, or Active
- **Health Score**: Calculates endpoint health based on call frequency and recency
- **Cost Estimation**: Estimates monthly waste and potential annual savings
- **Deprecation Code**: Exports middleware stubs in Node.js, Python, and Go
- **CSV Export**: Download analysis results for further processing
- **100% Private**: All processing happens locally in your browser

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Animation**: GSAP + ScrollTrigger
- **Auth**: Supabase (Google OAuth + GitHub OAuth)
- **Payments**: Lemon Squeezy (coming soon)
- **Deployment**: Vercel

## Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/deadlog.git
cd deadlog

# Install dependencies
npm install

# Start development server
npm run dev
```

### Environment Variables

Create a `.env` file in the root directory:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Usage

1. **Upload Logs**: Drag and drop a log file or paste log content directly
2. **Auto Detect**: Format is automatically detected (Nginx, CloudWatch, Express, JSON, CSV)
3. **Analyze**: Click "Analyze Logs" to process the data locally
4. **Review**: View endpoint health scores, status classifications, and cost estimates
5. **Export**: Download CSV, JSON, or deprecation code snippets

## Log Formats Supported

### Nginx
```
127.0.0.1 - - [24/Oct/2023:13:45:30 +0000] "GET /api/users HTTP/1.1" 200 1234 "-" "Mozilla/5.0"
```

### Express/Morgan
```
::1 - - [24/Oct/2023:13:45:30 +0000] "GET /api/users HTTP/1.1" 200 1234 "-" "Mozilla/5.0" 23.456 ms
```

### JSON
```json
{
  "timestamp": "2023-10-24T13:45:30Z",
  "method": "GET",
  "endpoint": "/api/users",
  "status": 200,
  "responseTime": 23.456
}
```

### AWS CloudWatch/ALB
```
https 2023-10-24T13:45:30.123456Z app/my-loadbalancer 192.168.1.1:1234 10.0.0.1:80 0.001 0.002 0.000 200 200 34 366 "GET https://example.com:443/api/users HTTP/1.1"
```

## Endpoint Classification

- **Dead**: No calls in the last 30 days
- **Low Traffic**: Fewer than 10 calls or no calls in the last 7 days
- **Active**: Regular traffic with recent calls

## Pricing

| Plan | Price | Features |
|------|-------|----------|
| Free | $0 | 3 projects, 1,000 analyses/month, 7-day history |
| Pro | $12/month | Unlimited projects, GitHub Actions, CI/CD hooks, historical trends |
| Team | $39/month | SSO, shared reports, priority support |
| Lifetime | $99 one-time | First 50 users only |

## Architecture

```
┌─────────────────┐
│   React App     │
│  (Client-side)  │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
┌───▼───┐  ┌──▼────┐
│ Log   │  │ Local │
│Parser │  │Storage│
└───┬───┘  └──┬────┘
    │         │
┌───▼─────────▼───┐
│  Analysis Result │
└─────────────────┘
```

All log processing happens entirely in the browser using JavaScript. No data is ever sent to a server.

## Project Structure

```
src/
├── components/
│   ├── dashboard/
│   │   ├── CostEstimateCard.tsx
│   │   ├── DeprecationModal.tsx
│   │   └── EndpointTable.tsx
│   ├── ui/              # shadcn/ui components
│   ├── LogUpload.tsx
│   └── Navigation.tsx
├── contexts/
│   └── AuthContext.tsx
├── hooks/
├── lib/
│   └── supabase.ts
├── pages/
│   ├── AuthCallback.tsx
│   ├── Dashboard.tsx
│   └── LandingPage.tsx
├── types/
│   └── index.ts
├── utils/
│   ├── logParser.ts
│   └── storage.ts
├── App.tsx
└── main.tsx
```

## Roadmap

- [ ] GitHub Action for automated log analysis
- [ ] CI/CD hooks for deployment pipelines
- [ ] Historical trend analysis
- [ ] Team collaboration features
- [ ] Custom log format builder
- [ ] API for programmatic access

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - see LICENSE file for details.

## Built By

Deadlog is built by a solo indie developer. Follow the journey on [Twitter](https://twitter.com/deadlog).

---

**Live Demo**: [https://wjfcksy5z5mky.ok.kimi.link](https://wjfcksy5z5mky.ok.kimi.link)
